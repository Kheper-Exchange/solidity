package QA;

import Require.Require;

import java.util.HashMap;
import java.util.Map;

public class QA {

    public final Require rq = new Require(); //for internal use as solidity's require!

    public final Map<Integer, Bid> statusMap = new HashMap<>();
    public final Map<String, Integer> withdrawnAmount = new HashMap<>();
    public int totalWithdrawn;
    public int totalInactive;
    public int lowestId;
    public int currentId;

    //----------METHODS FOR USE------------------
    public boolean ask(String usrAddress, int amount) throws Exception {
        rq.require(amount>0,"QA: ask amount == 0");
        rq.require(!usrAddress.equals("0"),"QA: address(0) not allowed");

        Bid bid = new Bid();
        bid.address = usrAddress;
        bid.amount = amount;
        statusMap.put(currentId,bid);
        ++currentId;
        return true;
    }

    public boolean answer(int amount) throws Exception {
        rq.require(amount>0,"QA: answer amount == 0");
        int totalamt = getTotalActiveAmount();

        rq.require(amount <= totalamt,"QA: amount > totalamt");
        rq.require((totalamt - amount) > (totalamt / 100) || totalamt - amount == 0,"QA: answer creates dust");

        if (amount == totalamt) {
            lowestId = currentId;
        } else {
            answerSplitter(amount);
        }
        totalInactive += amount;
        return true;
    }


    private void answerSplitter(int amount) throws Exception {
        int newLowestId = lowestId, current = statusMap.get(newLowestId).amount;
        int y=0;
        while (amount != 0) {
            rq.require(y<10000,"QA: too many answer entries to process");
            if (current > amount) {
                statusMap.get(newLowestId).amount = amount;
                ask(statusMap.get(newLowestId).address, current - amount);
                ++newLowestId;
                amount = 0;
            } else if (current == amount) {
                ++newLowestId;
                amount = 0;
            } else {
                amount -= current;
                ++newLowestId;
            }
            current = statusMap.get(newLowestId).amount;
            ++y;
        }

        lowestId = newLowestId;
    }

    //maybe not a part of UI
    private boolean processCancel(String userAddress, int amount) throws Exception {
        rq.require(amount>0,"QA: cancel amount == 0");
        rq.require(amount<=getTotalUserActiveAmount(userAddress),"QA: cancel amount must not exceed the allowed active amount");
        answer(amount);
        return true;
    }

    public boolean cancelAll(String userAddress) throws Exception {
        rq.require(!userAddress.equals("0"),"QA: address(0) not allowed");
        int active = getTotalUserActiveAmount(userAddress);
        rq.require(active>0,"QA: cancelAll amount == 0");
        processCancel(userAddress, active);
        return true;
    }

    //maybe not a part of UI
    private boolean withdraw(String userAddress, int amount) throws Exception {
        rq.require(amount>0,"QA: cancel amount == 0");
        rq.require(amount<=getTotalUserActiveAmount(userAddress),"QA: cancel amount must not exceed the allowed active amount");
        int wamt = withdrawnAmount.containsKey(userAddress) ? withdrawnAmount.get(userAddress) : 0;
        wamt += amount;
        withdrawnAmount.put(userAddress,wamt);
        totalWithdrawn += amount;
        return true;
    }

    public boolean withdrawAll(String userAddress) throws Exception {
        rq.require(!userAddress.equals("0"),"QA: address(0) not allowed");
        int inactive = getTotalUserInactiveAmount(userAddress);
        rq.require(inactive>0,"QA: withdrawAll amount == 0");
        withdraw(userAddress, inactive);
        return true;
    }

    //----------END OF METHODS FOR USE------------------

    //This is the total amount that is traded
    public int getTotalActiveAmount() throws Exception {
        int ret = 0;
        int y = lowestId;
        while (y< currentId) {
            rq.require(y<10000,"QA: too many active entries to process");
            ret += statusMap.get(y).amount;
            ++y;
        }
        return ret;
    }

    //This is the total amount that needs to be withdrawn
    public int getTotalInactiveAmount(){
        return totalInactive-totalWithdrawn;
    }

    //this is amount that userAddress is trading
    public int getTotalUserActiveAmount(String userAddress) throws Exception {
        int ret = 0, y = lowestId;
        while (y < currentId) {
            rq.require(y<10000,"QA: too many active entries to process");
			if (statusMap.get(y).address.equals(userAddress)) {
				ret += statusMap.get(y).amount;
			}
            ++y;
        }
        return ret;
    }

    //this is the amount that userAddress can withdraw
    public int getTotalUserInactiveAmount(String address) throws Exception {
        int ret = 0, trackAmt = totalInactive;
        int t = 0;
        while (t < lowestId) {
            rq.require(t<10000,"QA: too many inactive entries to process");
            if (address.equals(statusMap.get(t).address)) {
				int amt = statusMap.get(t).amount;
				if (amt > trackAmt) {
					ret += trackAmt;
					break;
				}
				ret += amt;
				trackAmt -= amt;
			}
			++t;
		}
        if(withdrawnAmount.containsKey(address))
            ret -= withdrawnAmount.get(address);
        return ret;
    }

    //returns the status of this QA
    //1-active 0-inactive 2-withdraw-only
    public byte getQAStatus() throws Exception {
		int inactive = getTotalInactiveAmount(), active = getTotalActiveAmount();
		return (byte) (active == 0 && inactive == 0 ? 0 : active != 0 ? 1 : 2);
	}







}
