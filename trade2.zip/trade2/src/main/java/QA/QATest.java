package QA;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class QATest {


public static void main(String[] args) throws Exception {
    Gson gson = new GsonBuilder().setPrettyPrinting().create();

    String usr1 = "user1";
    String usr2 = "user2";


    QA qa = new QA();
    qa.ask(usr1, 1);
    qa.ask(usr1, 2);
    qa.ask(usr1, 3);
    qa.ask(usr1, 4);
//    System.out.println(gson.toJson(qa));
//    System.out.println("-----------------------");
    qa.answer(7);
    qa.cancelAll(usr1);




    System.out.println(gson.toJson(qa));
    System.out.println("getTotalActiveAmount: " +qa.getTotalActiveAmount());
    System.out.println("getTotalInactiveAmount: " +qa.getTotalInactiveAmount());
    System.out.println("getTotalUserActiveAmount: " +qa.getTotalUserActiveAmount(usr1));
    System.out.println("getTotalUserInactiveAmount: " +qa.getTotalUserInactiveAmount(usr1));
    System.out.println("getQAStatus: " +qa.getQAStatus());




}


}
