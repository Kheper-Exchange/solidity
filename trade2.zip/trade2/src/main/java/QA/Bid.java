package QA;

public class Bid {
    String address;
    Integer amount;
}
