package TradingNode;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class TestTradingNode {
    public static void main(String[] args) throws Exception {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String usr1 = "usr1";

        TradingNode tn = new TradingNode("native", "NN", 1000);

//        tn.sellNative(usr1, 123);
        tn.sellNative(usr1, 123);
        tn.buyNative(usr1, 125);


        System.out.println(gson.toJson(tn));

    }

}
