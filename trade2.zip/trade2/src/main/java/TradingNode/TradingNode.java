package TradingNode;

//if I place native and ask for non-native, I am selling native and buying non-native
//if I place non-native and ask for native, I am buying native and selling non-native
//I can only buy or sell native


import QA.QA;
import Require.Require;

public class TradingNode {
    public final Require rq = new Require(); //for internal use as solidity's require!

    public final String nonNativeAddress;
    public final String nativeAddress; //can be hardcoded!

    public final int nativeToken = 1000; //one nativeToken as 1 with decimals (18)
    public int priceIndex; //set to 0 for an inactive node!
    public int previousPriceIndex = 0; //refers to external node
    public int nextPriceIndex = 0; //refers to external node
    public QA buy = new QA();
    public QA sell = new QA();

    public TradingNode(String nativeAddress, String nonNativeAddress, int priceIndex) {
        this.priceIndex = priceIndex;
        this.nativeAddress = nativeAddress;
        this.nonNativeAddress = nonNativeAddress;
    }

    //1-active 0-inactive 2-withdraw-only
    public byte getNodeStatus() throws Exception {
        byte buyStats = buy.getQAStatus();
        byte sellStats = sell.getQAStatus();
        if(buyStats==0){
            return sellStats;
        }
        else if(buyStats==1){
            return 1;
        }
        else if(buyStats==2 && sellStats!=1){
            return buyStats;
        }
        else {
            return 1;
        }
    }

    public byte buyNative(String usrAddress, int nonNativeAmount) throws Exception {
        rq.require(nonNativeAmount>0,"TN: nonNativeAmount == 0");
        rq.require(!usrAddress.equals("0"),"TN: address(0) not allowed");

        int nativeAmount = toNative(nonNativeAmount);
        if(nativeAmount==0) return 0;
        byte index = placeBuy(usrAddress, nativeAmount);
        if(index==0){return 0;}
        //send to contract
        return index;
    }

    //TODO before executing, get the view's conversion of non-native to native
    public byte sellNative(String usrAddress, int nativeAmount) throws Exception {
        rq.require(nativeAmount>0,"TN: nativeAmount == 0");
        rq.require(!usrAddress.equals("0"),"TN: address(0) not allowed");
        byte index = placeSell(usrAddress, nativeAmount);
        rq.require(index!=0,"TN: address(0) not allowed");

        return index;
    }

    //todo Note, do the view first for each, this is to be done on the top level!
    public boolean cancelAll(String userAddress) throws Exception {
        rq.require(!userAddress.equals("0"),"TN: address(0) not allowed");

        buy.cancelAll(userAddress);
        sell.cancelAll(userAddress);
        return true;
    }

    //todo Note, do the view first for each, this is to be done on the top level!
    public boolean withdrawAll(String userAddress) throws Exception {
        rq.require(!userAddress.equals("0"),"TN: address(0) not allowed");

        buy.withdrawAll(userAddress);
        sell.withdrawAll(userAddress);
        return true;
    }

    //if buy, and then sell exists, answer sell then ask buy with a remainder
    //if buy, and then sell does not exist, ask buy
    private byte placeBuy(String userAddress, int nativeAmount) throws Exception {
        byte ret = 1;
        int amt = sell.getTotalActiveAmount();
        if(amt!=0){
            if(amt >= nativeAmount){
                rq.require(sell.answer(nativeAmount), "TN: sell not answered");
            }
            else{
                rq.require(sell.answer(amt),"TN: failed placing sell in place buy");
                rq.require(buy.ask(userAddress,nativeAmount- amt),"TN: failed placing sell in place buy"); //TODO CHECK FOR BUGS!
                ret = 2;
            }
        }
        else{
            rq.require(buy.ask(userAddress,nativeAmount),"TN: sell not asked");
        }
        return ret;
    }

    //if sell and then buy exists, answer buy and then ask sell with a remainder
    //if sell and then buy does not exist, ask sell
    private byte placeSell(String userAddress, int nativeAmount) throws Exception {
        byte ret = 1;
        int amt = buy.getTotalActiveAmount();
        if(amt!=0){
            if(amt >= nativeAmount){
                rq.require(buy.answer(nativeAmount),"TN: Buy not answered");
            }
            else{
                rq.require(buy.answer(amt),"TN: buy not answered.");
                rq.require(sell.ask(userAddress,nativeAmount- amt),"TN: sell not asked");
                ret = 2;
            }
        }
        else{
            rq.require(sell.ask(userAddress,nativeAmount),"TN: sell not asked");
        }
        return ret;
    }

    private int toNative(int nonNativeAmount) throws Exception {
        rq.require(priceIndex>0,"TN: priceIndex == 0");
        return (nonNativeAmount*nativeToken)/priceIndex;
    }

    private int toNonNative(int nativeAmount) throws Exception {
        rq.require(nativeToken>0,"TN: nativeToken == 0");
        return (nativeAmount*priceIndex)/nativeToken;
    }

}
