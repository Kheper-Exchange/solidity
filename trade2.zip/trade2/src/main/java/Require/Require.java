package Require;

public class Require {

    public void require(boolean condition, String statement) throws Exception {
        if(!condition){
            throw new Exception(statement);
        }
    }

}
