package ActiveIndexes;


import Require.Require;
import TradingNode.TradingNode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

 public class ActiveIndexes {
     public final Require rq = new Require(); //for internal use as solidity's require!

    public final String nonNativeAddress;
    public final String nativeAddress;

    public int lowestKnownPriceIndex = 0;
    public int highestKnownPriceIndex = 0;
    public int currentIndex = 0;

    final Map<Integer, TradingNode> tradingPool = new HashMap<>();

    public ActiveIndexes(String nonNativeAddress, String nativeAddress){
        this.nonNativeAddress = nonNativeAddress;
        this.nativeAddress = nativeAddress;
    }


    //#############LOGIC FOR TRADING##############################

    //purchase native for non native
    public boolean buy(String userAddress, int priceIndex, int amount) throws Exception {
        rq.require(!userAddress.equals("0"),"AI: code 1");
        rq.require(priceIndex!=0,"AI: code 2");
        rq.require(amount!=0,"AI: code 3");

        if(!tradingPool.containsKey(priceIndex)){
            insertNewNode(priceIndex);
        }
        byte index = tradingPool.get(priceIndex).buyNative(userAddress,amount);
        if(index==2){currentIndex = priceIndex;}
        if(tradingPool.get(priceIndex).getNodeStatus()!=1){
            removeNode(priceIndex);
        }
        return index == 1 || index == 2;
    }

    //purchase non native for native
    public boolean sell(String userAddress, int priceIndex, int amount) throws Exception {
        rq.require(!userAddress.equals("0"),"AI: code 4");
        rq.require(priceIndex!=0,"AI: code 5");
        rq.require(amount!=0,"AI: code 6");

        if(!isNodeActive(priceIndex)){
            insertNewNode(priceIndex);
        }
        byte index = tradingPool.get(priceIndex).sellNative(userAddress,amount);
        if(index==2){currentIndex = priceIndex;}
        if(tradingPool.get(priceIndex).getNodeStatus()!=1){
            removeNode(priceIndex);
        }

        return index == 1 || index == 2;
    }

//    public boolean cancelAt(String userAddress, int priceIndex) throws Exception {
//        if(priceIndex==0 || !isNodeActive(priceIndex)) return false;
//        tradingPool.get(priceIndex).cancelBuyNativeOrder(userAddress);
//        tradingPool.get(priceIndex).cancelSellNativeOrder(userAddress);
//
//        //find the current index if inactive, and remove it
//        if(!tradingPool.get(priceIndex).isNodeActive()) {
//            int prevIndex = tradingPool.get(priceIndex).previousPriceIndex;
//            int nextIndex = tradingPool.get(priceIndex).nextPriceIndex;
//
//            if (prevIndex == 0 && nextIndex == 0) {
//                currentIndex = 0;
//            } else if (prevIndex == 0) {
//                currentIndex = nextIndex;
//            } else if (nextIndex == 0) {
//                currentIndex = prevIndex;
//            } else {
//                int dprev = priceIndex - prevIndex;
//                int dnext = nextIndex - priceIndex;
//                if (dprev > dnext) {
//                    currentIndex = prevIndex;
//                } else {
//                    currentIndex = nextIndex;
//                }
//            }
//            removeNode(priceIndex);
//        }
//
//        return true;
//    }

    //#############LOGIC FOR REMOVING##############################

    public boolean removeNode(int priceIndex){
        if(priceIndex>highestKnownPriceIndex){return false;}
        else if(priceIndex<lowestKnownPriceIndex){return false;}
        else{
            int prev = tradingPool.get(priceIndex).previousPriceIndex;
            int nxt = tradingPool.get(priceIndex).nextPriceIndex;
//            tradingPool.get(priceIndex).deactivateNode();

            if(prev==0 && nxt==0){
                 lowestKnownPriceIndex = 0;
                 highestKnownPriceIndex = 0;
                 currentIndex = 0;
            }

            else {

                if (prev != 0) {
                    tradingPool.get(prev).nextPriceIndex = nxt;
                }
                if (nxt != 0) {
                    tradingPool.get(nxt).previousPriceIndex = prev;
                }

                if (priceIndex == lowestKnownPriceIndex) {
                    if(currentIndex == lowestKnownPriceIndex){
                        currentIndex = nxt;
                    }
                    lowestKnownPriceIndex = nxt;
                }
                if (priceIndex == highestKnownPriceIndex) {
                    if(currentIndex == highestKnownPriceIndex){
                        currentIndex = prev;
                    }
                    highestKnownPriceIndex = prev;
                }
            }

        }
        return true;
    }
    //#############END FOR REMOVING##############################

    //#############LOGIC FOR INSERTING##############################
    public boolean insertNewNode(int priceIndex) throws Exception {
		if (priceIndex == 0)
			return false;
		if (isNodeActive(priceIndex))
			return false;
		else if (highestKnownPriceIndex == 0 && currentIndex == 0 && lowestKnownPriceIndex == 0) {
			addFirstNode(priceIndex);
		} else if (priceIndex > highestKnownPriceIndex) {
			addOnTop(priceIndex);
		} else if (priceIndex < lowestKnownPriceIndex) {
			addToBottom(priceIndex);
		} else {
			int nextLoc = lookForIndexUp(priceIndex);
			if (nextLoc == 0) {
				nextLoc = lookForIndexDown(priceIndex);
			}
			if (nextLoc == 0) {
				return false;
			}
			insertNode(priceIndex, nextLoc);
		}
		return true;
	}


    private int lookForIndexDown(int priceIndex) throws Exception {
        if(!isActiveIndexOperating()){
            return 0;
        }

        int crrnt = highestKnownPriceIndex;
        for(int t=0;t<10000;t++){
            if(crrnt==0) { return 0; }
            crrnt = tradingPool.get(crrnt).previousPriceIndex;
            if(crrnt<priceIndex && isNodeActive(crrnt)) return tradingPool.get(crrnt).nextPriceIndex;
        }
        return 0;

    }

    private int lookForIndexUp(int priceIndex) throws Exception {
        if(!isActiveIndexOperating()){
            return 0;
        }
        int crrnt = lowestKnownPriceIndex;
        for(int t=0;t<10000;++t){
            if(crrnt==0) { return 0; }
            crrnt = tradingPool.get(crrnt).nextPriceIndex;
            if(crrnt>priceIndex && isNodeActive(crrnt)) return crrnt;
        }
        return 0;
    }



    private void addToBottom(int priceIndex) {
        tradingPool.get(lowestKnownPriceIndex).previousPriceIndex = priceIndex;
        TradingNode tn = setNewNode(priceIndex, 0, lowestKnownPriceIndex);
        tn.nextPriceIndex = lowestKnownPriceIndex;
        lowestKnownPriceIndex = priceIndex;
        tradingPool.put(priceIndex, tn);
    }

    private void addOnTop(int priceIndex) {
        tradingPool.get(highestKnownPriceIndex).nextPriceIndex = priceIndex;
        TradingNode tn = setNewNode(priceIndex,highestKnownPriceIndex,0);
        tn.previousPriceIndex = highestKnownPriceIndex;
        highestKnownPriceIndex = priceIndex;
        tradingPool.put(priceIndex, tn);
    }

    private void insertNode(int priceIndex, int nextLoc) {
        int prevloc = tradingPool.get(nextLoc).previousPriceIndex;
        TradingNode tn = setNewNode(priceIndex,prevloc, nextLoc);
        tradingPool.put(priceIndex, tn);

        //squeeze it in
        tradingPool.get(nextLoc).previousPriceIndex = priceIndex;
        tradingPool.get(prevloc).nextPriceIndex = priceIndex;
    }

    private void addFirstNode(int priceIndex) {
        TradingNode tn = setNewNode(priceIndex,0,0);
        currentIndex = priceIndex;
        highestKnownPriceIndex = priceIndex;
        lowestKnownPriceIndex = priceIndex;
        tradingPool.put(priceIndex, tn);
    }

    private TradingNode setNewNode(int priceIndex, int previousPriceIndex, int nextPriceIndex) {
        TradingNode tn = new TradingNode(nativeAddress, nonNativeAddress, priceIndex);
        tn.priceIndex = priceIndex;
        tn.previousPriceIndex = previousPriceIndex;
        tn.nextPriceIndex = nextPriceIndex;
        return tn;
    }
//#############END LOGIC FOR INSERTING##############################


    private boolean isNodeActive(int priceIndex) throws Exception {
		return tradingPool.containsKey(priceIndex) && (tradingPool.get(priceIndex).getNodeStatus()==1);
	}

    public boolean isActiveIndexOperating(){
    return (highestKnownPriceIndex!=0 && currentIndex!=0 && lowestKnownPriceIndex!=0);
    }

//    public String getTradeString() throws Exception {
//        String ret = "Price\t|\tBuy Amount\t|\tSellAmount";
//        ret=ret+"\n"+"-------------------------------------------\n";
//        int backFive = currentIndex;
//        if(!isActiveIndexOperating()) return ret;
//        for(int t=0;t<5;t++){
//            int bck = tradingPool.get(currentIndex).previousPriceIndex;
//            if(bck==0) break;
//            backFive = bck;
//        }
//
//        for(int t=0;t<10;t++){
//            if(backFive==0) break;
//            int priceIndex = tradingPool.get(backFive).priceIndex;
//            int amountBuy = tradingPool.get(backFive).buy.getTotalActiveAmount();
//            int amountSell = tradingPool.get(backFive).sell.getTotalActiveAmount();
//            ret = ret+priceIndex+"\t\t\t"+amountBuy+"\t\t\t"+amountSell;
//            if(backFive==currentIndex){
//                ret = ret+" <-------";
//            }
//            ret = ret+"\n";
//            backFive = tradingPool.get(backFive).nextPriceIndex;
//        }
//        return ret;
//    }
//
//    public int[] testPrint(){
//        ArrayList<Integer> arr = new ArrayList<>();
//        int crrnt = lowestKnownPriceIndex;
//        while(crrnt!=0){
//            arr.add(crrnt);
//            crrnt = tradingPool.get(crrnt).nextPriceIndex;
//        }
//        int[] ret = new int[arr.size()];
//        for(int t=0;t<ret.length;t++){
//            ret[t] = arr.get(t);
//        }
//        Arrays.sort(ret);
//        return ret;
//    }


}
